package com.company;

public class Main {

    public static void main(String[] args) {

        printMegaBytesAndKiloBytes(2500);

        System.out.println(shouldWakeUp(true, 2));shouldWakeUp(true, 23);
    }

    public static void printMegaBytesAndKiloBytes(int kiloBytes){
        if(kiloBytes < 0){
            System.out.println("Invalid Value");
        }else{
            System.out.println(kiloBytes + " KB = " + kiloBytes/1024 +
                    " MB and " + kiloBytes%1024 + " KB ");
        }
    }

    public static boolean shouldWakeUp(boolean isBarking, int hourOfDay){
        if (hourOfDay < 0 || hourOfDay > 23){
            System.out.println("Ivalid Value");
            return false;
        }
        if(isBarking && (hourOfDay<8 || hourOfDay>23)){
            return true;
        }else if(isBarking || (hourOfDay<8 || hourOfDay>23)){
            return false;
        }else if(!isBarking &&  (hourOfDay<8 || hourOfDay>23)){
            return false;
        }else if(!isBarking || (hourOfDay<8 || hourOfDay>23)){
            return false;
        }
        return false;
    }
}
