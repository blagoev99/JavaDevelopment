public class Hello {

    public static void main(String[] args){
        System.out.println("Hello!");

        int myFirstNumber = (10+5)+(2*10);
        int mySecondNumber = 12;
        int myThirdNumber = 6;
        int myTotal = myFirstNumber + mySecondNumber + myThirdNumber;
        System.out.println(myTotal);
    }
}
