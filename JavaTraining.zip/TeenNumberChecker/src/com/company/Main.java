package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println(hasTeen(15,44, 65));
        System.out.println(hasTeen(11, 22, 43));
    }

    public static boolean hasTeen(int firstAge, int secondAge, int thirdAge){
        if(isTeen(firstAge) || isTeen(secondAge) || isTeen(thirdAge)){
            return true;
        }
        return false;
    }

    public static boolean isTeen(int ageToCheck){
        if (ageToCheck <= 19 && ageToCheck >= 13){
            return true;
        }
        return false;
    }
}
