package com.company;
//Lyboslav Blagoev
//F90645

public class Main {

    public static void main(String[] args) {
        checkForDifference(10, 10000, 5000);
        doubleHourglass(6);

    }

    //FIRST TASK
    public static void checkForDifference(int fromNumber, int toNumber, int difference){
        for(int i = fromNumber; i < toNumber; i++){
            int originalNumber = i;  //Saving the value

            String changedNumber = Integer.toString(i); //Converting the number to a string
           // changedNumber = changedNumber.substring(1); //Removing the first symbol from the string

            String firstDigit = changedNumber.substring(0, 1); //Getting the first digit
            String restOfNumber = changedNumber.substring(1); //Getting the rest of the digits

            String newNumber = restOfNumber + firstDigit;  //Concatenating the two parts
            int newInt = Integer.parseInt(newNumber); //Converting to an integer


            int realDifference = Math.abs(newInt) - Math.abs(i); //Calculating the difference between the two numbers

            if(realDifference > difference){  //Checking if the difference meets the criteria
                System.out.println(i + " " + newInt + " => " + i + " - " + newInt +
                        " = " + realDifference + " > " + difference);
                //Printing the answer in the expected format
            }
        }
    }

    //SECOND TASK
    public static void doubleHourglass(int upToNumber){
        System.out.print("\n");

        //Creating the upper part of the hourglass pattern
        for(int i = 1; i <= upToNumber; i++){

            //Creating indentation for each row (equal to 'i' for each cycle)
            for(int j = 0; j < i; j++) {
                System.out.print("  ");
            }

            //Printing the numbers in upgoing manner
            for(int j = i; j <= upToNumber; j++) {
                System.out.print(j + " ");
            }

            //Printing the numbers in downgoing manner
            for(int j = upToNumber; j >= i; j--){
                System.out.print(j + " ");
            }

            //Creating a new line after each row
            System.out.print('\n');
        }

        //Creating the bottom part of the hourglass pattern
        for(int i = upToNumber-1; i >= 1; i--){

            //Creating indentation for each row( equal to 'i' for each cycle)
            for(int j = 0; j < i; j++) {
               System.out.print("  ");
            }

            //Printing the numbers in upgoing manner
            for(int j = i; j <= upToNumber; j++){
               System.out.print(j + " ");
            }

            //Printing the numbers in downgoing manner
            for(int j = upToNumber; j >= i; j--) {
               System.out.print(j + " ");
            }

            //Creating a new line after each row
            System.out.print('\n');
        }
    }
}
