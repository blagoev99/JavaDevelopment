package com.company;

public class Main {

    public static void main(String[] args) {
//      Zadacha 1
//            Zad1(10,10000);
//      Zadacha 2
        Zad2(4);
    }

    public static void Zad1(int bottom, int top){

        int difference = 5000;
        int inverted = 0;

        if(top < bottom){
            System.out.println("The interval is not entered correctly!");
        }else{
            for(int i = bottom; i < top; i++){
                inverted = MoveFirstNumber(i);
                if(Math.abs(i - inverted) > difference){
                    System.out.println(i + " " + inverted + " => " + i + " - " + inverted + " = " + Math.abs(i - inverted) + " > " + difference);
                }
            }
        }

    }

    public static int MoveFirstNumber(int num){
        int a = 0;

        if(num >=10 && num < 100){
            a = num / 10;
            num = ((num - a*10) * 10) + a;
        }
        else if(num >= 100 && num < 1000){
            a = num / 100;
            num = ((num - a*100) * 10) + a;
        }
        else if(num >= 1000) {
            a = num / 1000;
            num = ((num - a*1000) * 10) + a;
        }

        return num;
    }

    public static void Zad2(int size){
        System.out.print("\n");

        for(int i = 1; i <= size; i++){

            for(int j = 0; j < i; j++) {
                System.out.print(" ");
            }

            for(int j = i; j <= size; j++) {
                System.out.print(j);
            }

            for(int j = size; j >= i; j--){
                System.out.print(j);
            }

            System.out.print('\n');
        }

        for(int i = size; i >= 1; i--){

            for(int j = 0; j < i; j++) {
                System.out.print(" ");
            }

            for(int j = i; j <= size; j++){
                System.out.print(j);
            }

            for(int j = size; j >= i; j--) {
                System.out.print(j);
            }

            System.out.print('\n');
        }
    }

}
