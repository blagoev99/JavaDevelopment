package com.company;

public class Main {

    public static void main(String[] args) {

        System.out.println( hasEqualSum(1,1,2));
        System.out.println(hasEqualSum(2,3,6));
    }

    public static boolean hasEqualSum(int firstNum, int secondNum, int thirdNum){
        if((firstNum + secondNum) == thirdNum){
            return true;
        }
        return false;
    }
}
