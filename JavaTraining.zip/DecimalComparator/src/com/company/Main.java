package com.company;

public class Main {

    public static void main(String[] args) {

        System.out.println(areEqualByThreeDecimalPlaces(3.123456, 3.123567));
    }

    public static boolean areEqualByThreeDecimalPlaces(double firstNumber, double secondNumber){
        firstNumber *= 1000;
        secondNumber *= 1000;

        int firstCastedNum = (int) firstNumber;
        int secondCastedNum = (int) secondNumber;
         if(firstCastedNum != secondCastedNum){
             return false;
         }else{
             return true;
         }
    }
}
